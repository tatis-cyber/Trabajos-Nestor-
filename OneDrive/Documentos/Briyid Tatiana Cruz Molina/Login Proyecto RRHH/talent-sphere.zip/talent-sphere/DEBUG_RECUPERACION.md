# 🔍 Guía de Depuración - Recuperación de Contraseña

## Pasos para Diagnosticar el Problema

### 1. Verificar que Apache esté corriendo
- Abre XAMPP Control Panel
- Verifica que Apache esté en verde (Running)

### 2. Probar la recuperación de contraseña

1. Ve a: `http://localhost/talent-sphere/`
2. Haz clic en "¿Olvidaste tu Contraseña?"
3. Ingresa un email válido (ej: `admin@talentsphere.com`)
4. Haz clic en "Enviar"

### 3. Revisar el enlace de prueba

Después de solicitar la recuperación, ve a la página de login. Si el correo no se envió, verás un enlace de prueba en un cuadro azul.

**Haz clic en ese enlace directamente** - ese es el enlace que debería funcionar.

### 4. Verificar los logs

Los logs de PHP están en:
- Windows: `C:\xampp\php\logs\php_error_log`
- O en: `C:\xampp\apache\logs\error.log`

Busca mensajes que empiecen con:
- `Token generado para...`
- `Token guardado en BD...`
- `Router nueva-password...`
- `nuevaPassword - Token recibido...`

### 5. Probar el token manualmente

Si tienes el token, puedes probarlo directamente:

```
http://localhost/talent-sphere/test_token.php?token=TU_TOKEN_AQUI
```

Este script te dirá si el token es válido o no.

### 6. Verificar la base de datos

Ejecuta en phpMyAdmin:

```sql
USE talent_sphere;

-- Ver todos los tokens activos
SELECT id, email, token_recuperacion, token_expiracion 
FROM usuarios 
WHERE token_recuperacion IS NOT NULL 
AND token_expiracion > NOW();

-- Ver el último token generado
SELECT id, email, token_recuperacion, token_expiracion 
FROM usuarios 
ORDER BY id DESC 
LIMIT 1;
```

### 7. Probar el enlace directamente

Si tienes el token del correo o de la sesión, prueba este formato:

```
http://localhost/talent-sphere/index.php?ruta=nueva-password/TOKEN_AQUI
```

Reemplaza `TOKEN_AQUI` con el token real.

## Problemas Comunes y Soluciones

### Error: "ERR_CONNECTION_REFUSED"
**Causa:** Apache no está corriendo
**Solución:** Inicia Apache desde XAMPP Control Panel

### Error: "Enlace de recuperación inválido"
**Causa:** El token no se está parseando correctamente de la URL
**Solución:** Usa el enlace de prueba que aparece en la página de login

### Error: "El enlace de recuperación es inválido o ha expirado"
**Causa:** El token expiró (válido por 1 hora) o no existe en la BD
**Solución:** Solicita un nuevo enlace de recuperación

### El correo no llega
**Causa:** Configuración SMTP incorrecta o el correo está en spam
**Solución:** Usa el enlace de prueba que aparece en la página de login después de solicitar recuperación

## Archivos de Depuración Creados

- `test_token.php` - Prueba tokens manualmente
- Logs mejorados en `controlador/AuthControlador.php` y `index.php`

## Próximos Pasos

1. Solicita recuperación de contraseña
2. Revisa la página de login para el enlace de prueba
3. Haz clic en el enlace de prueba
4. Si funciona, el problema es el enlace del correo
5. Si no funciona, revisa los logs de PHP

