# 🌐 Talent Sphere - Sistema de Gestión de RRHH

Sistema de gestión de recursos humanos desarrollado en PHP con arquitectura MVC.

## 📋 Características

- ✅ Arquitectura MVC (Modelo-Vista-Controlador)
- ✅ Patrón Singleton para conexión a BD
- ✅ Validación de formularios con JavaScript
- ✅ Encriptación de contraseñas con bcrypt
- ✅ Sistema de sesiones seguro
- ✅ CRUD completo de usuarios
- ✅ Asignación de roles (Administrador/Funcionario)
- ✅ Diseño responsive

## 🚀 Instalación

### Requisitos
- XAMPP, WAMP o similar
- PHP 7.4 o superior
- MySQL 5.7 o superior
- Apache con mod_rewrite habilitado

### Pasos

1. **Copiar archivos**
   ```
   Copiar la carpeta "talent-sphere" a:
   - Windows: C:\xampp\htdocs\
   - Linux: /var/www/html/
   ```

2. **Ejecutar el instalador (RECOMENDADO)**
   ```
   Abrir en el navegador: http://localhost/talent-sphere/instalar.php
   Esto creará la BD y usuarios automáticamente.
   ¡Eliminar instalar.php después de usarlo!
   ```

   **O manualmente:**
   ```
   - Abrir phpMyAdmin: http://localhost/phpmyadmin
   - Importar el archivo: database.sql
   ```

3. **Configurar conexión (si es necesario)**
   ```
   Editar: config/Configuracion.php
   
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'talent_sphere');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   ```

4. **Acceder al sistema**
   ```
   URL: http://localhost/talent-sphere/
   ```

## 👤 Credenciales por defecto

| Usuario | Contraseña | Rol |
|---------|------------|-----|
| admin@talentsphere.com | admin123 | Administrador |
| admin | admin123 | Administrador |
| carlosgomez | password123 | Funcionario |
| marialopez | password123 | Funcionario |

## 📁 Estructura del Proyecto

```
talent-sphere/
├── assets/
│   ├── css/
│   │   └── styles.css      # Estilos principales
│   └── js/
│       ├── app.js          # JavaScript principal
│       └── validacion.js   # Validación de formularios
├── config/
│   ├── Configuracion.php   # Configuración general
│   ├── BaseDatos.php       # Singleton de conexión BD
│   └── helpers.php         # Funciones auxiliares
├── controlador/
│   ├── AuthControlador.php     # Login, registro, logout
│   └── UsuarioControlador.php  # CRUD usuarios
├── modelo/
│   └── Usuario.php         # Modelo de usuarios
├── vista/
│   ├── auth/
│   │   ├── login.php       # Página de login
│   │   └── registro.php    # Página de registro
│   ├── layouts/
│   │   ├── home.php        # Página principal
│   │   ├── dashboard.php   # Panel de control
│   │   └── 404.php         # Página de error
│   └── usuarios/
│       └── index.php       # Gestión de usuarios
├── .htaccess               # Configuración Apache
├── database.sql            # Script de base de datos
├── index.php               # Router principal
└── README.md               # Este archivo
```

## 🔐 Funcionalidades

### Públicas
- Home page informativa
- Registro de usuarios
- Login

### Usuario autenticado
- Dashboard con estadísticas
- Ver perfil

### Administrador
- CRUD completo de usuarios
- Asignación de roles
- Activar/Desactivar usuarios

## 🎨 Páginas incluidas

1. **Home** - Página de bienvenida con información del sistema
2. **Login** - Formulario de inicio de sesión
3. **Registro** - Formulario de registro con validación
4. **Dashboard** - Panel de control con estadísticas
5. **Usuarios** - Gestión completa (solo admin)

## ⚙️ Tecnologías

- **Backend:** PHP 7.4+
- **Base de datos:** MySQL
- **Frontend:** HTML5, CSS3, JavaScript
- **Patrón:** MVC
- **Seguridad:** bcrypt, prepared statements, XSS protection

## 📝 Notas

- Las contraseñas se encriptan con bcrypt (cost 12)
- Se usa PDO con prepared statements para prevenir SQL injection
- Validación tanto en cliente (JS) como en servidor (PHP)
- El sistema usa sesiones para mantener el estado del usuario

## 🤝 Créditos

Desarrollado como proyecto académico de RRHH.
Basado en diseño de React convertido a PHP MVC.

---
© 2025 Talent Sphere - Todos los derechos reservados
