<?php
// test_token.php - Script de prueba para verificar tokens
// Acceder: http://localhost/talent-sphere/test_token.php?token=TU_TOKEN_AQUI

ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'config/Configuracion.php';
require_once 'config/BaseDatos.php';
require_once 'config/helpers.php';
require_once 'modelo/Usuario.php';

$token = $_GET['token'] ?? '';

echo "<h1>Test de Token de Recuperación</h1>";
echo "<p><strong>Token recibido:</strong> " . htmlspecialchars($token) . "</p>";

if (empty($token)) {
    echo "<p style='color: red;'>❌ No se proporcionó token. Usa: ?token=TU_TOKEN</p>";
    exit;
}

try {
    $usuarioModelo = new Usuario(BaseDatos::conectar());
    $usuario = $usuarioModelo->buscarPorToken($token);
    
    if ($usuario) {
        echo "<p style='color: green;'>✅ Token válido encontrado!</p>";
        echo "<pre>";
        echo "Usuario ID: " . $usuario['id'] . "\n";
        echo "Email: " . $usuario['email'] . "\n";
        echo "Token: " . $usuario['token_recuperacion'] . "\n";
        echo "Expira: " . $usuario['token_expiracion'] . "\n";
        echo "</pre>";
        echo "<p><a href='index.php?ruta=nueva-password/" . urlencode($token) . "'>Ir a cambiar contraseña</a></p>";
    } else {
        echo "<p style='color: red;'>❌ Token no encontrado o expirado</p>";
        
        // Verificar si existe el token sin validar expiración
        $sql = "SELECT * FROM usuarios WHERE token_recuperacion = :token";
        $stmt = BaseDatos::conectar()->prepare($sql);
        $stmt->execute(['token' => $token]);
        $usuarioSinExp = $stmt->fetch();
        
        if ($usuarioSinExp) {
            echo "<p style='color: orange;'>⚠️ Token existe pero está expirado</p>";
            echo "<pre>";
            echo "Expiración: " . $usuarioSinExp['token_expiracion'] . "\n";
            echo "Ahora: " . date('Y-m-d H:i:s') . "\n";
            echo "</pre>";
        } else {
            echo "<p>El token no existe en la base de datos</p>";
        }
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

