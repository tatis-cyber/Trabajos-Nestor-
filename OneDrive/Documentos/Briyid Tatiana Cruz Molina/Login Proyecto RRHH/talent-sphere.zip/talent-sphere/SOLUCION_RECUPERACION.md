# 🔧 Solución para el Error de Recuperación de Contraseña

## Problema

Al hacer clic en el enlace del correo de recuperación, aparece el error:
**"ERR_CONNECTION_REFUSED" - localhost rechazó la conexión**

## Soluciones

### 1. Verificar que Apache esté corriendo

- Abre el **Panel de Control de XAMPP**
- Asegúrate de que **Apache** esté en estado "Running" (verde)
- Si no está corriendo, haz clic en "Start"

### 2. Verificar la URL del enlace

El enlace en el correo debe ser:

```
http://localhost/talent-sphere/index.php?ruta=nueva-password/TOKEN
```

### 3. Si el problema persiste, prueba esto:

#### Opción A: Usar el enlace de prueba en la página de login

1. Solicita recuperación de contraseña
2. Si el correo no se envía, verás un enlace de prueba en la página de login
3. Haz clic en ese enlace directamente

#### Opción B: Copiar y pegar el enlace manualmente

1. Abre el correo
2. Copia el enlace completo que aparece en el texto
3. Pégalo directamente en la barra de direcciones del navegador
4. Asegúrate de que Apache esté corriendo antes de hacer clic

#### Opción C: Verificar configuración de Apache

1. Abre `httpd.conf` en XAMPP
2. Verifica que `mod_rewrite` esté habilitado
3. Reinicia Apache

### 4. Verificar que las columnas de token existan

Ejecuta el script de migración si aún no lo has hecho:

```sql
-- En phpMyAdmin, ejecuta:
USE talent_sphere;
ALTER TABLE usuarios ADD COLUMN token_recuperacion VARCHAR(100) DEFAULT NULL;
ALTER TABLE usuarios ADD COLUMN token_expiracion DATETIME DEFAULT NULL;
```

## Cambios Realizados en el Código

✅ Mejorado el enlace en el correo (codificación URL)
✅ Mejorado el enrutamiento para manejar tokens correctamente
✅ Mejorado el manejo de errores en la recuperación
✅ Agregadas validaciones adicionales

## Prueba Rápida

1. Asegúrate de que Apache esté corriendo
2. Ve a: `http://localhost/talent-sphere/`
3. Haz clic en "¿Olvidaste tu Contraseña?"
4. Ingresa un email válido
5. Revisa tu correo o el enlace de prueba en la página de login
6. Haz clic en el enlace (o cópialo y pégalo en el navegador)

Si el problema persiste, verifica los logs de Apache en:
`C:\xampp\apache\logs\error.log`
