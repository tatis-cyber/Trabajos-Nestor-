<?php
// index.php - Router Principal del Sistema Talent Sphere

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Iniciar sesión
session_start();

// Cargar configuración
require_once 'config/Configuracion.php';
require_once 'config/BaseDatos.php';
require_once 'config/helpers.php';

// Cargar modelos
require_once 'modelo/Usuario.php';

// Cargar controladores
require_once 'controlador/AuthControlador.php';
require_once 'controlador/UsuarioControlador.php';

// Obtener la ruta
$ruta = $_GET['ruta'] ?? 'home';
$ruta = rtrim($ruta, '/');
$partes = explode('/', $ruta);

$controlador = $partes[0] ?? 'home';
$accion = $partes[1] ?? 'index';
$parametro = $partes[2] ?? null;

// Enrutamiento
switch ($controlador) {
    // === RUTAS PÚBLICAS ===
    case 'home':
    case '':
        $auth = new AuthControlador();
        $auth->home();
        break;

    case 'login':
        $auth = new AuthControlador();
        if ($accion === 'procesar') {
            $auth->procesarLogin();
        } else {
            $auth->login();
        }
        break;

    case 'registro':
        $auth = new AuthControlador();
        if ($accion === 'procesar') {
            $auth->procesarRegistro();
        } else {
            $auth->registro();
        }
        break;

    case 'recuperar':
        $auth = new AuthControlador();
        if ($accion === 'procesar') {
            $auth->procesarRecuperar();
        } else {
            $auth->recuperar();
        }
        break;

    case 'nueva-password':
        $auth = new AuthControlador();
        if ($accion === 'procesar') {
            $auth->procesarNuevaPassword();
        } else {
            // El token puede venir de dos formas:
            // 1. Como parámetro de consulta: ?ruta=nueva-password&token=TOKEN (desde correo)
            // 2. Como parte de la ruta: nueva-password/TOKEN (compatibilidad)
            $token = '';
            
            // Prioridad 1: Token desde parámetro de consulta (más robusto)
            if (isset($_GET['token']) && !empty($_GET['token'])) {
                $token = trim($_GET['token']);
            }
            // Prioridad 2: Token desde la ruta (compatibilidad hacia atrás)
            elseif (!empty($accion) && $accion !== 'index' && $accion !== 'procesar') {
                $token = urldecode($accion);
            } elseif (!empty($parametro)) {
                $token = urldecode($parametro);
            }
            
            // Debug: Log para ver qué está pasando
            error_log("Router nueva-password - Ruta completa: " . $ruta);
            error_log("Router nueva-password - Accion: " . $accion);
            error_log("Router nueva-password - Token desde GET: " . (isset($_GET['token']) ? substr($_GET['token'], 0, 20) : 'no') . "...");
            error_log("Router nueva-password - Token extraído: " . substr($token, 0, 20) . "...");
            
            $auth->nuevaPassword($token);
        }
        break;

    case 'logout':
        $auth = new AuthControlador();
        $auth->logout();
        break;

    // === RUTAS PROTEGIDAS ===
    case 'dashboard':
        $usuario = new UsuarioControlador();
        $usuario->dashboard();
        break;

    case 'usuarios':
        $usuario = new UsuarioControlador();
        switch ($accion) {
            case 'index':
            case '':
                $usuario->index();
                break;
            case 'crear':
                $usuario->crear();
                break;
            case 'guardar':
                $usuario->guardar();
                break;
            case 'editar':
                $usuario->editar($parametro);
                break;
            case 'actualizar':
                $usuario->actualizar($parametro);
                break;
            case 'eliminar':
                $usuario->eliminar($parametro);
                break;
            case 'estado':
                $usuario->cambiarEstado($parametro);
                break;
            case 'obtener':
                $usuario->obtener($parametro);
                break;
            case 'actualizar-ajax':
                $usuario->actualizarAjax();
                break;
            case 'eliminar-ajax':
                $usuario->eliminarAjax();
                break;
            default:
                $usuario->index();
        }
        break;

    // === RUTA 404 ===
    default:
        http_response_code(404);
        require_once 'vista/layouts/404.php';
        break;
}
