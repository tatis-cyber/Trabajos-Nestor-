<?php
// config/Configuracion.php - Configuración del Sistema Talent Sphere

// --- URL / RUTAS ---
// NOTA: Si Apache está en puerto 8080, cambia localhost por localhost:8080
define('BASE_PATH', '/talent-sphere');
define('BASE_URL', 'http://localhost:8080/talent-sphere/index.php');
define('APP_URL', 'http://localhost:8080/talent-sphere'); // URL base para enlaces en emails

// --- CONFIGURACIÓN DE BASE DE DATOS ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'talent_sphere');
define('DB_USER', 'root');
define('DB_PASS', '');

// --- CONFIGURACIÓN DE SESIÓN ---
define('SESSION_NAME', 'talent_sphere_session');
define('SESSION_LIFETIME', 3600); // 1 hora

// --- ROLES DEL SISTEMA ---
define('ROL_ADMIN', 'Administrador');
define('ROL_FUNCIONARIO', 'Funcionario');

// --- ESTADOS ---
define('ESTADO_ACTIVO', 'Activo');
define('ESTADO_INACTIVO', 'Inactivo');

// --- CONFIGURACIÓN SMTP (Gmail) ---
// Rellena aquí con tu correo y la clave de aplicación de Gmail
// ¡IMPORTANTE! Reemplaza los valores de ejemplo:
define('SMTP_USER', 'ronaldacademy223@gmail.com');          // <- TU CORREO DE GMAIL REAL
define('SMTP_PASS', 'aqgfjwgqluvrfwlu');  // <- TU CLAVE DE APLICACIÓN DE 16 CARACTERES
define('SMTP_FROM_NAME', 'TRonald');                // nombre del remitente