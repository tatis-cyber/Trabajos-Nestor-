# 🔧 Solución: ERR_CONNECTION_REFUSED

## ❌ El Problema

El error **"ERR_CONNECTION_REFUSED"** significa que **Apache no está corriendo** o no está escuchando en el puerto correcto.

## ✅ Solución Paso a Paso

### Paso 1: Verificar XAMPP Control Panel

1. Abre **XAMPP Control Panel**
2. Busca la sección de **Apache**
3. Verifica el estado:
   - 🟢 **Verde (Running)** = Apache está corriendo ✅
   - 🔴 **Rojo** = Apache NO está corriendo ❌
   - ⚪ **Gris** = Apache no está iniciado ❌

### Paso 2: Iniciar Apache

Si Apache **NO está corriendo**:

1. Haz clic en el botón **"Start"** junto a Apache
2. Espera unos segundos
3. Verás mensajes en la consola de XAMPP
4. Cuando veas "Apache started", está listo ✅

### Paso 3: Verificar que Funciona

1. Abre tu navegador
2. Ve a: `http://localhost/`
3. Deberías ver la página de **XAMPP** (con el logo y menú)
4. Si ves esto, Apache está funcionando ✅

### Paso 4: Acceder a tu Proyecto

1. Ve a: `http://localhost/talent-sphere/`
2. Deberías ver tu aplicación funcionando ✅

## 🔍 Diagnóstico Avanzado

### Si Apache NO inicia:

1. **Verifica el puerto 80:**
   - El puerto 80 puede estar ocupado por otro programa
   - En XAMPP Control Panel, haz clic en **"Config"** → **"httpd.conf"**
   - Busca `Listen 80` y cámbialo a `Listen 8080` si es necesario
   - Reinicia Apache

2. **Verifica el firewall:**
   - Windows puede estar bloqueando Apache
   - Permite Apache a través del firewall cuando Windows lo solicite

3. **Revisa los logs:**
   - Ve a: `C:\xampp\apache\logs\error.log`
   - Busca errores que puedan indicar el problema

### Script de Verificación

He creado un script para verificar el estado:
```
http://localhost/talent-sphere/verificar_apache.php
```

Este script te dirá exactamente qué está pasando.

## 📝 Resumen

**El problema NO es tu código**, es que **Apache no está corriendo**.

**Solución:**
1. Abre XAMPP Control Panel
2. Inicia Apache (botón Start)
3. Espera a que inicie
4. Prueba de nuevo

## ⚠️ Importante

- Apache debe estar corriendo **SIEMPRE** que quieras usar tu aplicación
- Si cierras XAMPP Control Panel, Apache se detiene
- Para que Apache inicie automáticamente, configura XAMPP como servicio (avanzado)

