# 🎉 Eventos Recreacionales - Plataforma Web

Una aplicación web moderna para gestionar eventos recreacionales, desarrollada con PHP siguiendo la arquitectura MVC (Model-View-Controller).

## 🎨 Características

- ✅ Arquitectura MVC limpia y escalable
- ✅ Sistema de autenticación (Login/Registro)
- ✅ Dashboard personalizado para usuarios
- ✅ Interfaz moderna con diseño responsive
- ✅ Colores: Blanco, Amarillo (#FFD93D) y Beige (#F5E6D3)
- ✅ Animaciones suaves y transiciones
- ✅ Base de datos MySQL

## 📋 Requisitos Previos

- PHP 7.4 o superior
- MySQL 5.7 o superior
- Apache con mod_rewrite habilitado
- Extensión PDO de PHP habilitada

## 🚀 Instalación

### 1. Configurar el Servidor Local

**Para XAMPP:**
- Coloca la carpeta `eventos-recreacionales` en `C:\xampp\htdocs\`
- Inicia Apache y MySQL desde el panel de control de XAMPP

**Para WAMP:**
- Coloca la carpeta en `C:\wamp64\www\`
- Inicia los servicios desde el panel de WAMP

**Para MAMP (Mac):**
- Coloca la carpeta en `/Applications/MAMP/htdocs/`
- Inicia los servicios de MAMP

### 2. Crear la Base de Datos

1. Abre phpMyAdmin en tu navegador: `http://localhost/phpmyadmin`
2. Crea una nueva base de datos llamada: `eventos_recreacionales`
3. Ejecuta el siguiente SQL:

```sql
CREATE DATABASE IF NOT EXISTS eventos_recreacionales 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE eventos_recreacionales;

-- Tabla de usuarios
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabla de eventos
CREATE TABLE IF NOT EXISTS eventos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    descripcion TEXT,
    fecha_evento DATE,
    ubicacion VARCHAR(200),
    imagen VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

### 3. Configurar la Conexión a la Base de Datos

Edita el archivo `config/database.php` y ajusta las credenciales según tu configuración:

```php
private $host = 'localhost';
private $db_name = 'eventos_recreacionales';
private $username = 'root';        // Cambia si es necesario
private $password = '';            // Cambia si es necesario
```

### 4. Acceder a la Aplicación

Abre tu navegador y visita:
```
http://localhost/eventos-recreacionales/
```

## 📁 Estructura del Proyecto

```
eventos-recreacionales/
├── index.php                 # Punto de entrada principal
├── .htaccess                 # Configuración de Apache
├── config/
│   └── database.php         # Configuración de base de datos
├── controllers/
│   ├── HomeController.php   # Controlador de la página principal
│   ├── AuthController.php   # Controlador de autenticación
│   └── EventController.php  # Controlador de eventos
├── models/
│   ├── User.php            # Modelo de usuario
│   └── Event.php           # Modelo de evento
├── views/
│   ├── home.php            # Vista de la página principal
│   ├── login.php           # Vista de inicio de sesión
│   ├── register.php        # Vista de registro
│   ├── dashboard.php       # Vista del dashboard
│   └── layouts/
│       ├── header.php      # Header compartido
│       └── footer.php      # Footer compartido
└── public/
    └── css/
        └── style.css       # Estilos CSS
```

## 🎯 Uso de la Aplicación

### Registro de Usuario
1. Haz clic en "Registrarse" en la página principal
2. Completa el formulario con tu información
3. Haz clic en "Crear Cuenta"

### Inicio de Sesión
1. Haz clic en "Iniciar Sesión"
2. Ingresa tu email y contraseña
3. Accede a tu dashboard personalizado

### Dashboard
- Ver todos los eventos disponibles
- Ver estadísticas de tus eventos
- Inscribirse a eventos (funcionalidad de ejemplo)

## 🎨 Paleta de Colores

- **Principal:** #FFD93D (Amarillo brillante)
- **Principal Oscuro:** #F4C430 (Amarillo dorado)
- **Secundario:** #F5E6D3 (Beige/Crema)
- **Fondo:** #FFFFFF (Blanco)
- **Texto:** #2C2C2C (Negro suave)

## 🔧 Personalización

### Cambiar los Colores
Edita las variables CSS en `public/css/style.css`:

```css
:root {
    --color-primary: #FFD93D;
    --color-secondary: #F5E6D3;
    /* ... más variables */
}
```

### Agregar Nuevos Eventos
Edita `controllers/HomeController.php` o `controllers/EventController.php` para modificar los eventos de ejemplo.

## 🐛 Solución de Problemas

### Error de conexión a la base de datos
- Verifica que MySQL esté ejecutándose
- Confirma que las credenciales en `config/database.php` sean correctas
- Asegúrate de que la base de datos `eventos_recreacionales` exista

### Las imágenes o CSS no cargan
- Verifica que mod_rewrite esté habilitado en Apache
- Revisa que el archivo .htaccess esté presente
- Comprueba los permisos de las carpetas

### Páginas en blanco
- Habilita la visualización de errores en PHP para diagnosticar
- Revisa los logs de Apache/PHP
- Verifica que todas las rutas de archivos sean correctas

## 📝 Notas de Desarrollo

- La aplicación usa **sesiones PHP** para manejar la autenticación
- Las contraseñas se almacenan con **password_hash()** para seguridad
- El sistema de rutas usa un enrutador simple basado en parámetros GET
- Los datos de eventos actualmente son estáticos (array en controladores)

## 🚀 Próximas Mejoras

- [ ] Sistema completo de gestión de eventos desde el dashboard
- [ ] Subida de imágenes para eventos
- [ ] Sistema de inscripción real a eventos
- [ ] Panel de administración
- [ ] Notificaciones por email
- [ ] Búsqueda y filtrado de eventos
- [ ] Calendario de eventos
- [ ] Sistema de valoraciones y comentarios

## 👨‍💻 Tecnologías Utilizadas

- **Backend:** PHP 7.4+
- **Base de Datos:** MySQL
- **Frontend:** HTML5, CSS3, JavaScript
- **Arquitectura:** MVC (Model-View-Controller)
- **Tipografías:** Poppins, Playfair Display (Google Fonts)

## 📄 Licencia

Este proyecto es de código abierto y está disponible para uso educativo.

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Por favor:
1. Haz fork del proyecto
2. Crea una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abre un Pull Request

---

¡Disfruta usando EventosREC! 🎉✨
