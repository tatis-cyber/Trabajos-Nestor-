<?php
require_once 'config/database.php';

class Event {
    private $conn;
    private $table = 'eventos';
    
    public $id;
    public $titulo;
    public $descripcion;
    public $fecha_evento;
    public $ubicacion;
    public $imagen;
    
    public function __construct() {
        $database = new Database();
        $this->conn = $database->getConnection();
    }
    
    public function getAll() {
        $query = "SELECT * FROM " . $this->table . " ORDER BY fecha_evento DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();
        
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function create() {
        $query = "INSERT INTO " . $this->table . " (titulo, descripcion, fecha_evento, ubicacion, imagen) 
                  VALUES (:titulo, :descripcion, :fecha_evento, :ubicacion, :imagen)";
        $stmt = $this->conn->prepare($query);
        
        $stmt->bindParam(':titulo', $this->titulo);
        $stmt->bindParam(':descripcion', $this->descripcion);
        $stmt->bindParam(':fecha_evento', $this->fecha_evento);
        $stmt->bindParam(':ubicacion', $this->ubicacion);
        $stmt->bindParam(':imagen', $this->imagen);
        
        return $stmt->execute();
    }
}
