<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle ?? 'Eventos Recreacionales'; ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Playfair+Display:wght@700;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="public/css/style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container nav-container">
            <a href="index.php" class="logo">
                <span class="logo-icon">🎉</span>
                <span class="logo-text">Eventos<span class="highlight">REC</span></span>
            </a>
            <div class="nav-links">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <span class="welcome-text">Hola, <?php echo htmlspecialchars($_SESSION['user_name']); ?>!</span>
                    <a href="index.php?action=logout" class="btn btn-outline">Cerrar Sesión</a>
                <?php else: ?>
                    <a href="index.php?action=login" class="btn btn-outline">Iniciar Sesión</a>
                    <a href="index.php?action=register" class="btn btn-primary">Registrarse</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>
