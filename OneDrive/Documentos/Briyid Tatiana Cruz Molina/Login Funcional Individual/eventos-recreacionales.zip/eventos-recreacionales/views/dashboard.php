<?php 
$pageTitle = 'Mi Dashboard - Eventos Recreacionales';
include 'views/layouts/header.php'; 
?>

<main class="main-content">
    <section class="dashboard-header">
        <div class="container">
            <div class="welcome-banner fade-in">
                <h1 class="dashboard-title">¡Hola, <?php echo htmlspecialchars($user_name); ?>! 👋</h1>
                <p class="dashboard-subtitle">Aquí están tus eventos próximos</p>
            </div>
        </div>
    </section>

    <?php if (isset($_SESSION['message'])): ?>
        <div class="container">
            <div class="alert alert-success">
                <?php 
                echo htmlspecialchars($_SESSION['message']); 
                unset($_SESSION['message']);
                ?>
            </div>
        </div>
    <?php endif; ?>

    <section class="dashboard-content">
        <div class="container">
            <div class="dashboard-stats fade-in">
                <div class="stat-card">
                    <div class="stat-icon">🎫</div>
                    <div class="stat-info">
                        <h3>Eventos Inscritos</h3>
                        <p class="stat-number">1</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">📅</div>
                    <div class="stat-info">
                        <h3>Próximos Eventos</h3>
                        <p class="stat-number"><?php echo count($eventos); ?></p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon">⭐</div>
                    <div class="stat-info">
                        <h3>Eventos Completados</h3>
                        <p class="stat-number">0</p>
                    </div>
                </div>
            </div>

            <h2 class="section-title fade-in">Todos los Eventos Disponibles</h2>
            <div class="events-grid">
                <?php foreach ($eventos as $index => $evento): ?>
                <div class="event-card fade-in" style="animation-delay: <?php echo $index * 0.1; ?>s;">
                    <?php if ($evento['inscrito']): ?>
                        <span class="badge-inscrito">Inscrito ✓</span>
                    <?php endif; ?>
                    
                    <div class="event-icon">
                        <?php 
                        $icons = ['🎵', '🏐', '🎬', '🧘'];
                        echo $icons[$index % 4]; 
                        ?>
                    </div>
                    <h3 class="event-title"><?php echo htmlspecialchars($evento['titulo']); ?></h3>
                    <div class="event-meta">
                        <span class="event-date">📅 <?php echo htmlspecialchars($evento['fecha']); ?></span>
                        <span class="event-location">📍 <?php echo htmlspecialchars($evento['ubicacion']); ?></span>
                    </div>
                    <p class="event-description"><?php echo htmlspecialchars($evento['descripcion']); ?></p>
                    
                    <?php if ($evento['inscrito']): ?>
                        <button class="btn btn-success btn-block" disabled>
                            Ya Inscrito
                        </button>
                    <?php else: ?>
                        <button class="btn btn-primary btn-block">
                            Inscribirse
                        </button>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
</main>

<?php include 'views/layouts/footer.php'; ?>
