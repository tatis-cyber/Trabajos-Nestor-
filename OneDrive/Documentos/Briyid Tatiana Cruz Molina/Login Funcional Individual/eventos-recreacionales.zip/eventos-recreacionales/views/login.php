<?php 
$pageTitle = 'Iniciar Sesión - Eventos Recreacionales';
include 'views/layouts/header.php'; 
?>

<main class="main-content auth-page">
    <div class="container">
        <div class="auth-container fade-in">
            <div class="auth-box">
                <div class="auth-header">
                    <h1 class="auth-title">Bienvenido de Nuevo</h1>
                    <p class="auth-subtitle">Inicia sesión para continuar</p>
                </div>

                <?php if (isset($_SESSION['message'])): ?>
                    <div class="alert alert-success">
                        <?php 
                        echo htmlspecialchars($_SESSION['message']); 
                        unset($_SESSION['message']);
                        ?>
                    </div>
                <?php endif; ?>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-error">
                        <?php 
                        echo htmlspecialchars($_SESSION['error']); 
                        unset($_SESSION['error']);
                        ?>
                    </div>
                <?php endif; ?>

                <form action="index.php?action=do_login" method="POST" class="auth-form">
                    <div class="form-group">
                        <label for="email" class="form-label">Email</label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            class="form-input" 
                            placeholder="tu@email.com" 
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="password" class="form-label">Contraseña</label>
                        <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            class="form-input" 
                            placeholder="••••••••" 
                            required
                        >
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        Iniciar Sesión
                    </button>
                </form>

                <div class="auth-footer">
                    <p>¿No tienes cuenta? <a href="index.php?action=register" class="auth-link">Regístrate aquí</a></p>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'views/layouts/footer.php'; ?>
