<?php 
$pageTitle = 'Registrarse - Eventos Recreacionales';
include 'views/layouts/header.php'; 
?>

<main class="main-content auth-page">
    <div class="container">
        <div class="auth-container fade-in">
            <div class="auth-box">
                <div class="auth-header">
                    <h1 class="auth-title">Crear Cuenta</h1>
                    <p class="auth-subtitle">Únete a la comunidad de EventosREC</p>
                </div>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-error">
                        <?php 
                        echo htmlspecialchars($_SESSION['error']); 
                        unset($_SESSION['error']);
                        ?>
                    </div>
                <?php endif; ?>

                <form action="index.php?action=do_register" method="POST" class="auth-form">
                    <div class="form-group">
                        <label for="nombre" class="form-label">Nombre Completo</label>
                        <input 
                            type="text" 
                            id="nombre" 
                            name="nombre" 
                            class="form-input" 
                            placeholder="Juan Pérez" 
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="email" class="form-label">Email</label>
                        <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            class="form-input" 
                            placeholder="tu@email.com" 
                            required
                        >
                    </div>

                    <div class="form-group">
                        <label for="password" class="form-label">Contraseña</label>
                        <input 
                            type="password" 
                            id="password" 
                            name="password" 
                            class="form-input" 
                            placeholder="••••••••" 
                            required
                            minlength="6"
                        >
                    </div>

                    <div class="form-group">
                        <label for="confirm_password" class="form-label">Confirmar Contraseña</label>
                        <input 
                            type="password" 
                            id="confirm_password" 
                            name="confirm_password" 
                            class="form-input" 
                            placeholder="••••••••" 
                            required
                            minlength="6"
                        >
                    </div>

                    <button type="submit" class="btn btn-primary btn-block">
                        Crear Cuenta
                    </button>
                </form>

                <div class="auth-footer">
                    <p>¿Ya tienes cuenta? <a href="index.php?action=login" class="auth-link">Inicia sesión aquí</a></p>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'views/layouts/footer.php'; ?>
