<?php 
$pageTitle = 'Inicio - Eventos Recreacionales';
include 'views/layouts/header.php'; 
?>

<main class="main-content">
    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content fade-in">
                <h1 class="hero-title">
                    Descubre Los Mejores
                    <span class="highlight-text">Eventos Recreacionales</span>
                </h1>
                <p class="hero-description">
                    Únete a una comunidad vibrante de personas que aman la diversión y el entretenimiento. 
                    Encuentra eventos increíbles cerca de ti.
                </p>
                <div class="hero-buttons">
                    <?php if (!isset($_SESSION['user_id'])): ?>
                        <a href="index.php?action=register" class="btn btn-primary btn-large">
                            Comenzar Ahora
                        </a>
                        <a href="index.php?action=login" class="btn btn-outline btn-large">
                            Iniciar Sesión
                        </a>
                    <?php else: ?>
                        <a href="index.php?action=dashboard" class="btn btn-primary btn-large">
                            Ver Mis Eventos
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="hero-decoration">
                <div class="decoration-circle decoration-1"></div>
                <div class="decoration-circle decoration-2"></div>
                <div class="decoration-circle decoration-3"></div>
            </div>
        </div>
    </section>

    <!-- Eventos Destacados -->
    <section class="events-section">
        <div class="container">
            <h2 class="section-title fade-in">Próximos Eventos</h2>
            <div class="events-grid">
                <?php foreach ($eventos as $index => $evento): ?>
                <div class="event-card fade-in" style="animation-delay: <?php echo $index * 0.1; ?>s;">
                    <div class="event-icon">
                        <?php 
                        $icons = ['🎵', '🏐', '🎬'];
                        echo $icons[$index % 3]; 
                        ?>
                    </div>
                    <h3 class="event-title"><?php echo htmlspecialchars($evento['titulo']); ?></h3>
                    <div class="event-meta">
                        <span class="event-date">📅 <?php echo htmlspecialchars($evento['fecha']); ?></span>
                        <span class="event-location">📍 <?php echo htmlspecialchars($evento['ubicacion']); ?></span>
                    </div>
                    <p class="event-description"><?php echo htmlspecialchars($evento['descripcion']); ?></p>
                    <a href="index.php?action=<?php echo isset($_SESSION['user_id']) ? 'dashboard' : 'register'; ?>" class="btn btn-card">
                        <?php echo isset($_SESSION['user_id']) ? 'Ver Detalles' : 'Registrarse para Participar'; ?>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="features-section">
        <div class="container">
            <h2 class="section-title fade-in">¿Por Qué Elegirnos?</h2>
            <div class="features-grid">
                <div class="feature-card fade-in">
                    <div class="feature-icon">🌟</div>
                    <h3>Variedad de Eventos</h3>
                    <p>Desde deportes hasta cultura, tenemos eventos para todos los gustos</p>
                </div>
                <div class="feature-card fade-in" style="animation-delay: 0.1s;">
                    <div class="feature-icon">👥</div>
                    <h3>Comunidad Activa</h3>
                    <p>Conoce personas con intereses similares y haz nuevos amigos</p>
                </div>
                <div class="feature-card fade-in" style="animation-delay: 0.2s;">
                    <div class="feature-icon">📱</div>
                    <h3>Fácil de Usar</h3>
                    <p>Registro simple y acceso rápido a todos tus eventos favoritos</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <?php if (!isset($_SESSION['user_id'])): ?>
    <section class="cta-section">
        <div class="container">
            <div class="cta-content fade-in">
                <h2 class="cta-title">¿Listo para la Diversión?</h2>
                <p class="cta-description">Únete ahora y no te pierdas ningún evento increíble</p>
                <a href="index.php?action=register" class="btn btn-primary btn-large">
                    Crear Cuenta Gratis
                </a>
            </div>
        </div>
    </section>
    <?php endif; ?>
</main>

<?php include 'views/layouts/footer.php'; ?>
