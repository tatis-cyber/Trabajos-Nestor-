<?php
class HomeController {
    public function index() {
        // Eventos de ejemplo
        $eventos = [
            [
                'titulo' => 'Festival de Música al Aire Libre',
                'fecha' => '15 Diciembre 2025',
                'ubicacion' => 'Parque Central',
                'descripcion' => 'Disfruta de bandas locales y comida deliciosa'
            ],
            [
                'titulo' => 'Torneo de Voleibol Playero',
                'fecha' => '20 Diciembre 2025',
                'ubicacion' => 'Playa Dorada',
                'descripcion' => 'Competencia amistosa para todas las edades'
            ],
            [
                'titulo' => 'Noche de Cine bajo las Estrellas',
                'fecha' => '25 Diciembre 2025',
                'ubicacion' => 'Plaza Mayor',
                'descripcion' => 'Películas clásicas en pantalla gigante'
            ]
        ];
        
        require_once 'views/home.php';
    }
}
