<?php
class EventController {
    
    public function dashboard() {
        $user_name = $_SESSION['user_name'] ?? 'Usuario';
        
        // Eventos próximos
        $eventos = [
            [
                'titulo' => 'Festival de Música al Aire Libre',
                'fecha' => '15 Diciembre 2025',
                'ubicacion' => 'Parque Central',
                'descripcion' => 'Disfruta de bandas locales y comida deliciosa',
                'inscrito' => false
            ],
            [
                'titulo' => 'Torneo de Voleibol Playero',
                'fecha' => '20 Diciembre 2025',
                'ubicacion' => 'Playa Dorada',
                'descripcion' => 'Competencia amistosa para todas las edades',
                'inscrito' => true
            ],
            [
                'titulo' => 'Noche de Cine bajo las Estrellas',
                'fecha' => '25 Diciembre 2025',
                'ubicacion' => 'Plaza Mayor',
                'descripcion' => 'Películas clásicas en pantalla gigante',
                'inscrito' => false
            ],
            [
                'titulo' => 'Clase de Yoga en el Parque',
                'fecha' => '28 Diciembre 2025',
                'ubicacion' => 'Jardín Botánico',
                'descripcion' => 'Sesión de yoga al amanecer',
                'inscrito' => false
            ]
        ];
        
        require_once 'views/dashboard.php';
    }
}
