<?php
require_once 'config/database.php';

class AuthController {
    
    public function login() {
        require_once 'views/login.php';
    }
    
    public function register() {
        require_once 'views/register.php';
    }
    
    public function doLogin() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            
            $database = new Database();
            $db = $database->getConnection();
            
            if ($db) {
                $query = "SELECT * FROM usuarios WHERE email = :email LIMIT 1";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                
                $user = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($user && password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['user_name'] = $user['nombre'];
                    $_SESSION['message'] = '¡Bienvenido, ' . $user['nombre'] . '!';
                    header('Location: index.php?action=dashboard');
                    exit;
                } else {
                    $_SESSION['error'] = 'Email o contraseña incorrectos';
                    header('Location: index.php?action=login');
                    exit;
                }
            }
        }
    }
    
    public function doRegister() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $nombre = $_POST['nombre'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $confirm_password = $_POST['confirm_password'] ?? '';
            
            // Validaciones básicas
            if (empty($nombre) || empty($email) || empty($password)) {
                $_SESSION['error'] = 'Todos los campos son requeridos';
                header('Location: index.php?action=register');
                exit;
            }
            
            if ($password !== $confirm_password) {
                $_SESSION['error'] = 'Las contraseñas no coinciden';
                header('Location: index.php?action=register');
                exit;
            }
            
            $database = new Database();
            $db = $database->getConnection();
            
            if ($db) {
                // Verificar si el email ya existe
                $query = "SELECT id FROM usuarios WHERE email = :email";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':email', $email);
                $stmt->execute();
                
                if ($stmt->rowCount() > 0) {
                    $_SESSION['error'] = 'Este email ya está registrado';
                    header('Location: index.php?action=register');
                    exit;
                }
                
                // Insertar nuevo usuario
                $query = "INSERT INTO usuarios (nombre, email, password) VALUES (:nombre, :email, :password)";
                $stmt = $db->prepare($query);
                $password_hash = password_hash($password, PASSWORD_DEFAULT);
                
                $stmt->bindParam(':nombre', $nombre);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password', $password_hash);
                
                if ($stmt->execute()) {
                    $_SESSION['message'] = 'Registro exitoso. Ya puedes iniciar sesión';
                    header('Location: index.php?action=login');
                    exit;
                } else {
                    $_SESSION['error'] = 'Error al registrar usuario';
                    header('Location: index.php?action=register');
                    exit;
                }
            }
        }
    }
    
    public function logout() {
        session_destroy();
        header('Location: index.php');
        exit;
    }
}
