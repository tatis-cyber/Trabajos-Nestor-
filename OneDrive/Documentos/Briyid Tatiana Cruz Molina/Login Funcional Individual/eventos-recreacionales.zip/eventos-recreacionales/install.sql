-- ============================================
-- Base de Datos: eventos_recreacionales
-- Fecha: Diciembre 2025
-- Descripción: Sistema de gestión de eventos recreacionales
-- ============================================

-- Crear base de datos
CREATE DATABASE IF NOT EXISTS eventos_recreacionales 
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE eventos_recreacionales;

-- ============================================
-- Tabla: usuarios
-- Descripción: Almacena información de los usuarios registrados
-- ============================================
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Tabla: eventos
-- Descripción: Almacena información de los eventos recreacionales
-- ============================================
CREATE TABLE IF NOT EXISTS eventos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    descripcion TEXT,
    fecha_evento DATE,
    ubicacion VARCHAR(200),
    imagen VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_fecha (fecha_evento)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Tabla: inscripciones (para futuras implementaciones)
-- Descripción: Relación entre usuarios y eventos
-- ============================================
CREATE TABLE IF NOT EXISTS inscripciones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    evento_id INT NOT NULL,
    fecha_inscripcion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    estado ENUM('pendiente', 'confirmado', 'cancelado') DEFAULT 'pendiente',
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (evento_id) REFERENCES eventos(id) ON DELETE CASCADE,
    UNIQUE KEY unique_inscripcion (usuario_id, evento_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================
-- Datos de Ejemplo: Eventos
-- ============================================
INSERT INTO eventos (titulo, descripcion, fecha_evento, ubicacion) VALUES
('Festival de Música al Aire Libre', 'Disfruta de bandas locales y comida deliciosa en un ambiente familiar', '2025-12-15', 'Parque Central'),
('Torneo de Voleibol Playero', 'Competencia amistosa para todas las edades con premios para los ganadores', '2025-12-20', 'Playa Dorada'),
('Noche de Cine bajo las Estrellas', 'Películas clásicas en pantalla gigante con palomitas gratis', '2025-12-25', 'Plaza Mayor'),
('Clase de Yoga en el Parque', 'Sesión de yoga al amanecer para todos los niveles', '2025-12-28', 'Jardín Botánico'),
('Taller de Arte para Niños', 'Actividades creativas y manualidades para los más pequeños', '2026-01-05', 'Centro Cultural'),
('Carrera 5K Familiar', 'Carrera recreativa con recorrido por el malecón', '2026-01-10', 'Malecón Principal');

-- ============================================
-- Usuario de Prueba
-- Contraseña: password123
-- ============================================
INSERT INTO usuarios (nombre, email, password) VALUES
('Usuario Demo', 'demo@eventosrec.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- ============================================
-- Verificar instalación
-- ============================================
SELECT 'Base de datos creada exitosamente' AS mensaje;
SELECT COUNT(*) AS total_eventos FROM eventos;
SELECT COUNT(*) AS total_usuarios FROM usuarios;
