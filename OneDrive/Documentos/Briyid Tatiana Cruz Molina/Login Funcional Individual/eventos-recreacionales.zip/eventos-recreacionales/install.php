<?php
/**
 * Instalador Automático
 * Este script crea automáticamente la base de datos y las tablas necesarias
 * 
 * IMPORTANTE: Elimina este archivo después de la instalación por seguridad
 */

$config = [
    'host' => 'localhost',
    'username' => 'root',
    'password' => '',
    'db_name' => 'eventos_recreacionales'
];

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Instalador - Eventos Recreacionales</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #F5E6D3 0%, #FFFFFF 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            max-width: 600px;
            width: 100%;
            background: white;
            border-radius: 20px;
            padding: 40px;
            box-shadow: 0 8px 32px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2C2C2C;
            margin-bottom: 10px;
            font-size: 32px;
        }
        .subtitle {
            color: #6B6B6B;
            margin-bottom: 30px;
        }
        .step {
            background: #F5E6D3;
            padding: 20px;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        .step h3 {
            color: #2C2C2C;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .step p {
            color: #6B6B6B;
            line-height: 1.6;
        }
        .success {
            background: #E8F5E9;
            border-left: 4px solid #4CAF50;
        }
        .error {
            background: #FFEBEE;
            border-left: 4px solid #F44336;
        }
        .warning {
            background: #FFF3E0;
            border-left: 4px solid #FF9800;
        }
        .btn {
            background: #FFD93D;
            color: #2C2C2C;
            padding: 14px 32px;
            border: none;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn:hover {
            background: #F4C430;
            transform: translateY(-2px);
        }
        code {
            background: #f5f5f5;
            padding: 2px 6px;
            border-radius: 4px;
            font-family: monospace;
        }
        .icon {
            font-size: 24px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🎉 Instalador EventosREC</h1>
        <p class="subtitle">Configuración automática de la base de datos</p>

        <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            try {
                // Conectar sin seleccionar base de datos
                $conn = new PDO(
                    "mysql:host={$config['host']}",
                    $config['username'],
                    $config['password']
                );
                $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

                echo '<div class="step success">';
                echo '<h3><span class="icon">✅</span> Conexión MySQL Exitosa</h3>';
                echo '<p>Conectado al servidor MySQL correctamente</p>';
                echo '</div>';

                // Crear base de datos
                $conn->exec("CREATE DATABASE IF NOT EXISTS {$config['db_name']} 
                            CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
                
                echo '<div class="step success">';
                echo '<h3><span class="icon">✅</span> Base de Datos Creada</h3>';
                echo '<p>Base de datos <code>' . $config['db_name'] . '</code> creada exitosamente</p>';
                echo '</div>';

                // Seleccionar base de datos
                $conn->exec("USE {$config['db_name']}");

                // Crear tabla usuarios
                $conn->exec("CREATE TABLE IF NOT EXISTS usuarios (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nombre VARCHAR(100) NOT NULL,
                    email VARCHAR(100) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    fecha_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_email (email)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

                echo '<div class="step success">';
                echo '<h3><span class="icon">✅</span> Tabla Usuarios Creada</h3>';
                echo '<p>Tabla para almacenar usuarios registrados</p>';
                echo '</div>';

                // Crear tabla eventos
                $conn->exec("CREATE TABLE IF NOT EXISTS eventos (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    titulo VARCHAR(200) NOT NULL,
                    descripcion TEXT,
                    fecha_evento DATE,
                    ubicacion VARCHAR(200),
                    imagen VARCHAR(255),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    INDEX idx_fecha (fecha_evento)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

                echo '<div class="step success">';
                echo '<h3><span class="icon">✅</span> Tabla Eventos Creada</h3>';
                echo '<p>Tabla para almacenar eventos recreacionales</p>';
                echo '</div>';

                // Crear tabla inscripciones
                $conn->exec("CREATE TABLE IF NOT EXISTS inscripciones (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    usuario_id INT NOT NULL,
                    evento_id INT NOT NULL,
                    fecha_inscripcion TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    estado ENUM('pendiente', 'confirmado', 'cancelado') DEFAULT 'pendiente',
                    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
                    FOREIGN KEY (evento_id) REFERENCES eventos(id) ON DELETE CASCADE,
                    UNIQUE KEY unique_inscripcion (usuario_id, evento_id)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

                echo '<div class="step success">';
                echo '<h3><span class="icon">✅</span> Tabla Inscripciones Creada</h3>';
                echo '<p>Tabla para relacionar usuarios con eventos</p>';
                echo '</div>';

                // Insertar eventos de ejemplo
                $stmt = $conn->query("SELECT COUNT(*) FROM eventos");
                if ($stmt->fetchColumn() == 0) {
                    $conn->exec("INSERT INTO eventos (titulo, descripcion, fecha_evento, ubicacion) VALUES
                        ('Festival de Música al Aire Libre', 'Disfruta de bandas locales y comida deliciosa', '2025-12-15', 'Parque Central'),
                        ('Torneo de Voleibol Playero', 'Competencia amistosa para todas las edades', '2025-12-20', 'Playa Dorada'),
                        ('Noche de Cine bajo las Estrellas', 'Películas clásicas en pantalla gigante', '2025-12-25', 'Plaza Mayor'),
                        ('Clase de Yoga en el Parque', 'Sesión de yoga al amanecer', '2025-12-28', 'Jardín Botánico')");

                    echo '<div class="step success">';
                    echo '<h3><span class="icon">✅</span> Datos de Ejemplo Insertados</h3>';
                    echo '<p>Se han agregado 4 eventos de ejemplo</p>';
                    echo '</div>';
                }

                echo '<div class="step success">';
                echo '<h3><span class="icon">🎉</span> ¡Instalación Completada!</h3>';
                echo '<p>Tu aplicación está lista para usar. <strong>Por seguridad, elimina este archivo (install.php)</strong></p>';
                echo '<p style="margin-top: 15px;"><a href="index.php" class="btn">Ir a la Aplicación</a></p>';
                echo '</div>';

            } catch (PDOException $e) {
                echo '<div class="step error">';
                echo '<h3><span class="icon">❌</span> Error de Instalación</h3>';
                echo '<p>' . htmlspecialchars($e->getMessage()) . '</p>';
                echo '<p style="margin-top: 10px;">Verifica que:</p>';
                echo '<ul style="margin-left: 20px; margin-top: 5px;">';
                echo '<li>MySQL esté ejecutándose</li>';
                echo '<li>Las credenciales sean correctas</li>';
                echo '<li>El usuario tenga permisos para crear bases de datos</li>';
                echo '</ul>';
                echo '</div>';
            }
        } else {
            ?>
            <div class="step">
                <h3><span class="icon">📋</span> Antes de Comenzar</h3>
                <p>Este instalador creará automáticamente:</p>
                <ul style="margin-left: 20px; margin-top: 10px; line-height: 1.8;">
                    <li>✓ Base de datos <code><?php echo $config['db_name']; ?></code></li>
                    <li>✓ Tabla de usuarios</li>
                    <li>✓ Tabla de eventos</li>
                    <li>✓ Tabla de inscripciones</li>
                    <li>✓ Datos de ejemplo</li>
                </ul>
            </div>

            <div class="step warning">
                <h3><span class="icon">⚠️</span> Configuración Actual</h3>
                <p><strong>Host:</strong> <?php echo $config['host']; ?></p>
                <p><strong>Usuario:</strong> <?php echo $config['username']; ?></p>
                <p><strong>Base de datos:</strong> <?php echo $config['db_name']; ?></p>
                <p style="margin-top: 10px; font-size: 14px;">
                    Si necesitas cambiar estos valores, edita el archivo <code>install.php</code>
                </p>
            </div>

            <form method="POST">
                <button type="submit" class="btn">🚀 Iniciar Instalación</button>
            </form>

            <div style="margin-top: 20px; padding: 15px; background: #f5f5f5; border-radius: 8px;">
                <p style="font-size: 14px; color: #6B6B6B;">
                    <strong>💡 Consejo:</strong> Después de la instalación, elimina este archivo por seguridad.
                </p>
            </div>
            <?php
        }
        ?>
    </div>
</body>
</html>
